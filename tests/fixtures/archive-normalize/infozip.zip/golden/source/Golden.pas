unit Golden;

interface

implementation

end.
