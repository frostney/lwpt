# golden

Normalizer fixture.
